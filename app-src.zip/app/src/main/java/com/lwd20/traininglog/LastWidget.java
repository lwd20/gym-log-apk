package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class LastWidget extends AppWidgetProvider {
  static final int[] N = {R.id.lwn0, R.id.lwn1, R.id.lwn2, R.id.lwn3, R.id.lwn4, R.id.lwn5};
  static final int[] V = {R.id.lwv0, R.id.lwv1, R.id.lwv2, R.id.lwv3, R.id.lwv4, R.id.lwv5};
  static final int[] S = {R.id.lws0, R.id.lws1, R.id.lws2, R.id.lws3, R.id.lws4, R.id.lws5};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, LastWidget.class));
    if (ids == null || ids.length == 0) return;
    RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_last);
    JSONArray a = null;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) a = new JSONObject(raw).optJSONArray("lw");
    } catch (Exception e) {}
    int n = a == null ? 0 : a.length();
    rv.setTextViewText(R.id.root_cnt, n > 0 ? String.valueOf(n) : "");
    for (int i = 0; i < 6; i++) {
      if (i < n) {
        try {
          JSONArray r = a.getJSONArray(i);
          rv.setTextViewText(N[i], r.getString(0));
          rv.setTextViewText(V[i], r.getString(1));
          rv.setTextViewText(S[i], tail(r, 2));
          rv.setViewVisibility(N[i], View.VISIBLE);
          rv.setViewVisibility(V[i], View.VISIBLE);
          rv.setViewVisibility(S[i], View.VISIBLE);
          continue;
        } catch (Exception e) {}
      }
      rv.setViewVisibility(N[i], View.GONE);
      rv.setViewVisibility(V[i], View.GONE);
      rv.setViewVisibility(S[i], View.GONE);
    }
    rv.setViewVisibility(R.id.root_empty, n == 0 ? View.VISIBLE : View.GONE);
    if (n == 0) rv.setTextViewText(R.id.root_empty, "기록 없음");
    Intent it = new Intent(c, MainActivity.class);
    rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE));
    for (int wi = 0; wi < ids.length; wi++) {
      int id = ids[wi];
      int cbg = WCfg.bg(c, id), cop = WCfg.op(c, id);
      boolean cl = !WCfg.lightText(cbg, cop, WCfg.txMode(c, id));
      WCfg.paint(rv, cbg, cop);
      applyTheme(rv, cl);
      m.updateAppWidget(id, rv);
    }
  }

  static String tail(JSONArray r, int idx) {
    try {
      int v = r.getInt(idx);
      if ("lw".equals("td")) return v + "\uc138\ud2b8";
      if (v <= 0) return "\uc624\ub298";
      return v + "\uc77c \uc804";
    } catch (Exception e) { return ""; }
  }

  static void applyTheme(RemoteViews rv, boolean lt) {
    rv.setTextColor(R.id.root_hd, WTheme.head(lt));
    rv.setTextColor(R.id.root_cnt, WTheme.mute(lt));
    rv.setTextColor(R.id.root_empty, WTheme.dim(lt));
    WTheme.tint(rv, N, WTheme.label(lt));
    WTheme.tint(rv, V, WTheme.value(lt));
    WTheme.tint(rv, S, WTheme.dim(lt));
  }
}
