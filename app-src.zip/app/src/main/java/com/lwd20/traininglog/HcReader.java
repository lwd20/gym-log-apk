package com.lwd20.traininglog;

import android.app.Activity;
import android.health.connect.HealthConnectException;
import android.health.connect.HealthConnectManager;
import android.health.connect.AggregateRecordsGroupedByPeriodResponse;
import android.health.connect.AggregateRecordsRequest;
import android.health.connect.LocalTimeRangeFilter;
import android.health.connect.ReadRecordsRequestUsingFilters;
import android.health.connect.ReadRecordsResponse;
import android.health.connect.TimeInstantRangeFilter;
import android.health.connect.datatypes.MealType;
import android.health.connect.datatypes.NutritionRecord;
import android.health.connect.datatypes.StepsRecord;
import android.health.connect.datatypes.WeightRecord;
import android.health.connect.datatypes.units.Energy;
import android.health.connect.datatypes.units.Mass;
import android.os.OutcomeReceiver;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 헬스 커넥트에서 섭취 영양을 읽어 날짜별로 합친다.
 *
 * 안드로이드 14부터 헬스 커넥트가 OS 안에 들어와서 라이브러리 없이 쓸 수 있다.
 * 이 앱은 그래들 의존성이 하나도 없는 순수 프레임워크 앱이라 이 길을 택했다.
 *
 * 여기 나오는 클래스는 전부 API 34 이므로 이 파일은 SDK_INT 검사를 통과한
 * 뒤에만 건드려야 한다 — 이름만 스쳐도 옛 기기에서 클래스 로딩이 터진다.
 * 그래서 HealthBridge 와 파일을 나눠 두었다.
 */
final class HcReader {

  private HcReader() {}

  /**
   * 에너지 단위를 실측으로 정한다.
   *
   * 플랫폼 Energy 에는 getInCalories() 하나뿐이고 킬로칼로리 메서드가 없다.
   * 문서만 봐서는 738kcal 짜리 저녁이 738 로 오는지 738000 으로 오는지 알 수 없어
   * 값의 크기로 가른다. 사람이 하루에 20000kcal 를 넘길 수는 없으므로
   * 그 위로 나오면 단위가 cal 인 것이고 1000 으로 나눈다. 여유가 아주 크다.
   */
  private static double kcal(double raw) {
    return raw > 20000 ? raw / 1000.0 : raw;
  }

  /** 질량도 같은 이유로. 하루 단백질이 5000g 일 수는 없다 */
  private static double grams(double raw) {
    return raw > 5000 ? raw / 1000.0 : raw;
  }

  private static double e(Energy v) { return v == null ? 0 : kcal(v.getInCalories()); }
  private static double m(Mass v) { return v == null ? 0 : grams(v.getInGrams()); }

  interface Done {
    void ok(String json);
    void fail(String why);
  }

  /** 하루치 또는 한 끼니의 누적 */
  private static final class Sum {
    double kcal, p, c, f;
    int n;

    void add(NutritionRecord r) {
      kcal += e(r.getEnergy());
      p += m(r.getProtein());
      c += m(r.getTotalCarbohydrate());
      f += m(r.getTotalFat());
      n++;
    }

    String json() {
      return "{\"kcal\":" + Math.round(kcal)
          + ",\"p\":" + Math.round(p)
          + ",\"c\":" + Math.round(c)
          + ",\"f\":" + Math.round(f)
          + ",\"n\":" + n + "}";
    }
  }

  /** 하루 = 합계 + 끼니별 */
  private static final class Day {
    final Sum all = new Sum();
    final Map<String, Sum> meals = new LinkedHashMap<>();

    Sum meal(String k) {
      Sum v = meals.get(k);
      if (v == null) { v = new Sum(); meals.put(k, v); }
      return v;
    }
  }

  /* 상수를 이름으로 짚는다 — 숫자를 짐작하면 틀려도 조용히 넘어간다 */
  private static String mealKey(int t) {
    if (t == MealType.MEAL_TYPE_BREAKFAST) return "breakfast";
    if (t == MealType.MEAL_TYPE_LUNCH) return "lunch";
    if (t == MealType.MEAL_TYPE_DINNER) return "dinner";
    if (t == MealType.MEAL_TYPE_SNACK) return "snack";
    return "other";
  }

  static void read(final Activity act, int days, final Done cb) {
    HealthConnectManager hcm = act.getSystemService(HealthConnectManager.class);
    if (hcm == null) { cb.fail("서비스 없음"); return; }

    final ZoneId zone = ZoneId.systemDefault();
    Instant from = LocalDate.now(zone).minusDays(Math.max(0, days - 1))
        .atStartOfDay(zone).toInstant();
    Instant to = Instant.now();

    ReadRecordsRequestUsingFilters<NutritionRecord> req =
        new ReadRecordsRequestUsingFilters.Builder<>(NutritionRecord.class)
            .setTimeRangeFilter(new TimeInstantRangeFilter.Builder()
                .setStartTime(from).setEndTime(to).build())
            .build();

    hcm.readRecords(req, act.getMainExecutor(),
        new OutcomeReceiver<ReadRecordsResponse<NutritionRecord>, HealthConnectException>() {
          @Override public void onResult(ReadRecordsResponse<NutritionRecord> res) {
            final String food;
            try { food = fold(res.getRecords(), zone); }
            catch (Throwable t) { cb.fail(String.valueOf(t.getMessage())); return; }
            readWeight(act, hcm, zone, from, to, food, cb);
          }
          @Override public void onError(HealthConnectException ex) {
            cb.fail(ex.getClass().getSimpleName() + ": " + ex.getMessage());
          }
        });
  }

  /* 체중 권한만 따로 거부할 수 있다 — 실패해도 영양은 살려서 내보낸다 */
  private static void readWeight(Activity act, HealthConnectManager hcm, final ZoneId zone,
                                 Instant from, Instant to, final String food, final Done cb) {
    try {
      ReadRecordsRequestUsingFilters<WeightRecord> wr =
          new ReadRecordsRequestUsingFilters.Builder<>(WeightRecord.class)
              .setTimeRangeFilter(new TimeInstantRangeFilter.Builder()
                  .setStartTime(from).setEndTime(to).build())
              .build();
      hcm.readRecords(wr, act.getMainExecutor(),
          new OutcomeReceiver<ReadRecordsResponse<WeightRecord>, HealthConnectException>() {
            @Override public void onResult(ReadRecordsResponse<WeightRecord> res) {
              String withW;
              try { withW = merge(food, "w", foldW(res.getRecords(), zone)); }
              catch (Throwable t) { withW = food; }
              readSteps(act, hcm, zone, from, to, withW, cb);
            }
            @Override public void onError(HealthConnectException ex) {
              readSteps(act, hcm, zone, from, to, food, cb);
            }
          });
    } catch (Throwable t) { readSteps(act, hcm, zone, from, to, food, cb); }
  }

  /* 걸음 권한도 따로 거부할 수 있다 — 실패해도 앞의 둘은 살려서 내보낸다.
     걸음은 하루 활동계수를 날마다 다르게 잡는 데 쓴다: 지하철을 두 번 갈아탄
     날과 종일 앉아 있던 날이 같은 소비로 잡히면 적자가 그만큼 틀어진다.

     레코드를 그대로 읽어 더했더니 삼성헬스가 4,556 보라 한 날이 8,456 보가 됐다.
     헬스 커넥트에는 여러 앱이, 또 한 앱이 굵기가 다른 토막으로 같은 시간대를
     겹쳐 쓴다 — 날것을 더하면 겹친 만큼 부풀 수밖에 없다. 겹침을 걷어 내는 일은
     집계(aggregate)가 맡는다. 그러라고 있는 API 다.
     하루 경계로 묶으려면 지역시간 필터라야 한다(LocalTimeRangeFilter). */
  private static void readSteps(Activity act, HealthConnectManager hcm, final ZoneId zone,
                                Instant from, Instant to, final String prev, final Done cb) {
    try {
      java.time.LocalDateTime lFrom = java.time.LocalDateTime.ofInstant(from, zone);
      java.time.LocalDateTime lTo = java.time.LocalDateTime.ofInstant(to, zone);
      AggregateRecordsRequest<Long> req =
          new AggregateRecordsRequest.Builder<Long>(
              new LocalTimeRangeFilter.Builder().setStartTime(lFrom).setEndTime(lTo).build())
              .addAggregationType(StepsRecord.STEPS_COUNT_TOTAL)
              .build();
      hcm.aggregateGroupByPeriod(req, java.time.Period.ofDays(1), act.getMainExecutor(),
          new OutcomeReceiver<List<AggregateRecordsGroupedByPeriodResponse<Long>>,
                              HealthConnectException>() {
            @Override public void onResult(List<AggregateRecordsGroupedByPeriodResponse<Long>> res) {
              try { cb.ok(merge(prev, "steps", foldS(res))); }
              catch (Throwable t) { cb.ok(prev); }
            }
            @Override public void onError(HealthConnectException ex) { cb.ok(prev); }
          });
    } catch (Throwable t) { cb.ok(prev); }
  }

  /* 집계가 하루씩 묶어 돌려준 것을 날짜별 수로 편다. 그 하루에 걸음이 없으면
     null 이 오는데, 0 으로 적지 않고 아예 빼 둔다 — 웹이 '안 들어온 날' 과
     '안 걸은 날' 을 가를 수 있어야 한다. */
  private static String foldS(List<AggregateRecordsGroupedByPeriodResponse<Long>> res) {
    StringBuilder sb = new StringBuilder("{");
    boolean first = true;
    for (AggregateRecordsGroupedByPeriodResponse<Long> g : res) {
      Long n = g.get(StepsRecord.STEPS_COUNT_TOTAL);
      if (n == null || n <= 0) continue;
      if (!first) sb.append(',');
      first = false;
      sb.append('"').append(g.getStartTime().toLocalDate().toString())
        .append("\":").append(n.longValue());
    }
    return sb.append('}').toString();
  }

  /** 앞서 만든 JSON 뒤에 한 갈래를 덧붙인다 — 끝의 '}' 를 떼고 이어 붙인다.
      체중만 붙이던 것을 키를 받게 넓혔다. 걸음도 같은 자리에 붙기 때문이다. */
  private static String merge(String base, String key, String val) {
    int i = base.lastIndexOf('}');
    if (i < 0) return base;
    return base.substring(0, i) + ",\"" + key + "\":" + val + "}";
  }

  /* 하루에 여러 번 잰 값이 전부 개별 레코드로 온다. 어느 것을 쓸지는 웹이
     정하므로 [분, kg] 로 시각을 붙여 그대로 넘긴다.
     Mass 는 그램이라 72.4kg 이 72400 으로 온다 — 영양 쪽 grams() 의 크기 짐작을
     여기에 쓰면 단위가 뒤섞이므로 따로 나눈다. */
  private static String foldW(List<WeightRecord> recs, ZoneId zone) {
    Map<String, StringBuilder> by = new LinkedHashMap<>();
    for (WeightRecord r : recs) {
      if (r.getWeight() == null) continue;
      double kg = r.getWeight().getInGrams() / 1000.0;
      if (!(kg >= 20 && kg <= 300)) continue;      /* 사람 몸무게가 아니면 버린다 */
      ZoneOffset off = r.getZoneOffset();
      java.time.LocalDateTime lt = (off != null ? r.getTime().atOffset(off).toLocalDateTime()
                                                : r.getTime().atZone(zone).toLocalDateTime());
      String k = lt.toLocalDate().toString();
      int mins = lt.getHour() * 60 + lt.getMinute();
      StringBuilder b = by.get(k);
      if (b == null) { b = new StringBuilder("["); by.put(k, b); }
      else b.append(',');
      b.append('[').append(mins).append(',').append(Math.round(kg * 10) / 10.0).append(']');
    }
    StringBuilder sb = new StringBuilder("{");
    boolean first = true;
    for (Map.Entry<String, StringBuilder> en : by.entrySet()) {
      if (!first) sb.append(',');
      first = false;
      sb.append('"').append(en.getKey()).append("\":").append(en.getValue()).append(']');
    }
    return sb.append('}').toString();
  }

  /** 기록을 그 기록이 적힌 지역 날짜로 묶는다 — 밤 11시 간식이 다음 날로 새면 안 된다 */
  private static String fold(List<NutritionRecord> recs, ZoneId zone) {
    Map<String, Day> by = new LinkedHashMap<>();
    double rawFirst = -1;
    for (NutritionRecord r : recs) {
      ZoneOffset off = r.getStartZoneOffset();
      LocalDate d = (off != null ? r.getStartTime().atOffset(off).toLocalDate()
                                 : r.getStartTime().atZone(zone).toLocalDate());
      String k = d.toString();
      Day day = by.get(k);
      if (day == null) { day = new Day(); by.put(k, day); }
      if (rawFirst < 0 && r.getEnergy() != null) rawFirst = r.getEnergy().getInCalories();
      day.all.add(r);
      day.meal(mealKey(r.getMealType())).add(r);
    }
    StringBuilder sb = new StringBuilder("{\"ok\":true,\"raw\":").append(rawFirst)
        .append(",\"days\":{");
    boolean first = true;
    for (Map.Entry<String, Day> en : by.entrySet()) {
      if (!first) sb.append(',');
      first = false;
      Day v = en.getValue();
      String a = v.all.json();
      /* 합계 뒤에 끼니별을 덧붙인다 — 합계만 있으면 '저녁을 안 먹었다'를 알 수 없다 */
      StringBuilder ms = new StringBuilder(",\"meals\":{");
      boolean f2 = true;
      for (Map.Entry<String, Sum> mm : v.meals.entrySet()) {
        if (!f2) ms.append(',');
        f2 = false;
        ms.append('"').append(mm.getKey()).append("\":").append(mm.getValue().json());
      }
      ms.append('}');
      sb.append('"').append(en.getKey()).append("\":")
        .append(a, 0, a.length() - 1).append(ms).append('}');
    }
    return sb.append("}}").toString();
  }
}
