package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 볼륨 랜드마크(MRV) 위젯 — 분석탭의 그래프를 홈 화면으로 옮긴 것.
 *
 * 구간(MEV / MAV / 감량 보정 MRV)은 부위마다 고정된 상수라 레이아웃의
 * layout_weight 에 구워져 있다. 여기서는 현재 세트 수만 얹는다.
 * 비트맵을 쓰지 않으므로 Binder 전송량이나 메모리 부담이 없다.
 *
 * 웹이 [이름, 현재세트, 축최대] 를 내려준다. 축최대는 분석탭과 같은 식으로
 * 계산된 값이라 막대 길이가 앱 그래프와 일치한다.
 */
public class LmWidget extends AppWidgetProvider {
  static final int[] NM = {R.id.lmn0, R.id.lmn1, R.id.lmn2, R.id.lmn3, R.id.lmn4};
  static final int[] BAR = {R.id.lb0, R.id.lb1, R.id.lb2, R.id.lb3, R.id.lb4};
  static final int[] VAL = {R.id.lmv0, R.id.lmv1, R.id.lmv2, R.id.lmv3, R.id.lmv4};
  /** 막대 해상도 — 축최대를 1000 단계로 쪼개 반올림 오차를 줄임 */
  static final int STEPS = 1000;

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  @Override public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
    push(c);
  }

  static void push(Context c) {
    CrashLog.install(c);
    try { pushInner(c); } catch (Throwable t) { CrashLog.save(c, t); }
  }

  static void pushInner(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, LmWidget.class));
    if (ids == null || ids.length == 0) return;

    String[] nm = new String[5];
    int[] cur = new int[5];
    double[] mx = new double[5];
    boolean[] over = new boolean[5];
    boolean has = false;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      JSONArray a = raw == null ? null : new JSONObject(raw).optJSONArray("lm");
      if (a != null) {
        for (int i = 0; i < 5 && i < a.length(); i++) {
          JSONArray r = a.getJSONArray(i);
          nm[i] = r.getString(0);
          cur[i] = r.getInt(1);
          mx[i] = r.getDouble(2);
          over[i] = r.optInt(3, 0) == 1;   /* 보정 MRV 초과 여부는 웹이 판정 */
          has = true;
        }
      }
    } catch (Exception e) { has = false; }

    String stale = WDate.staleTag(c);

    PendingIntent pi = PendingIntent.getActivity(c, 0,
        new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

    for (int wi = 0; wi < ids.length; wi++) {
      int id = ids[wi];
      RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_lm);
      int cbg = WCfg.bg(c, id), cop = WCfg.op(c, id);
      boolean lt = !WCfg.lightText(cbg, cop, WCfg.txMode(c, id));

      rv.setTextViewText(R.id.lm_hd, "VOLUME LANDMARKS" + stale);
      rv.setTextColor(R.id.lm_hd, WTheme.head(lt));

      for (int i = 0; i < 5; i++) {
        boolean on = has && nm[i] != null;
        rv.setViewVisibility(NM[i], on ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(VAL[i], on ? View.VISIBLE : View.GONE);
        rv.setViewVisibility(BAR[i], on ? View.VISIBLE : View.GONE);
        if (!on) continue;
        rv.setTextViewText(NM[i], nm[i]);
        rv.setTextColor(NM[i], WTheme.head(lt));
        rv.setTextViewText(VAL[i], String.valueOf(cur[i]));
        /* 보정 MRV 를 넘겼으면 숫자를 경고색으로 — 막대 드로어블은 런타임에 못 바꾼다 */
        rv.setTextColor(VAL[i], over[i] ? 0xFFD9603F : WTheme.value(lt));
        int p = mx[i] > 0 ? (int) Math.round(cur[i] / mx[i] * STEPS) : 0;
        rv.setProgressBar(BAR[i], STEPS, Math.max(0, Math.min(STEPS, p)), false);
      }

      rv.setTextViewText(R.id.lm_foot, has ? "눈금 = 감량 보정 MRV" : "앱을 한 번 열면 동기화됨");
      rv.setTextColor(R.id.lm_foot, WTheme.dim(lt));

      rv.setOnClickPendingIntent(R.id.root, pi);
      WCfg.paint(rv, cbg, cop);
      m.updateAppWidget(id, rv);
    }
  }
}
