package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class VolumeWidget extends AppWidgetProvider {
  static final int[] LB = {R.id.l1, R.id.l2, R.id.l3, R.id.l4, R.id.l5};
  static final int[] BR = {R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, VolumeWidget.class));
    if (ids == null || ids.length == 0) return;
    RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_volume);
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw == null) {
        rv.setTextViewText(R.id.l1, "Open PLUS2.5 once to sync");
        for (int i = 1; i < 5; i++) rv.setTextViewText(LB[i], "");
      } else {
        JSONArray v = new JSONObject(raw).getJSONArray("v");
        for (int i = 0; i < 5; i++) {
          if (i < v.length()) {
            JSONArray r = v.getJSONArray(i);
            String name = r.getString(0);
            int n = r.getInt(1), t = r.getInt(2);
            rv.setTextViewText(LB[i], name + "  " + n + "/" + t);
            rv.setProgressBar(BR[i], t, Math.min(n, t), false);
          } else {
            rv.setTextViewText(LB[i], "");
            rv.setProgressBar(BR[i], 1, 0, false);
          }
        }
      }
    } catch (Exception e) {}
    Intent it = new Intent(c, MainActivity.class);
    rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE));
    m.updateAppWidget(ids, rv);
  }
}
