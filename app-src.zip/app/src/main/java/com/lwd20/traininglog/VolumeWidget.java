package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class VolumeWidget extends AppWidgetProvider {
  static final int[] LB = {R.id.l1, R.id.l2, R.id.l3, R.id.l4, R.id.l5, R.id.l6};
  static final int[] BR = {R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5, R.id.b6};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    CrashLog.install(c);
    try { pushInner(c); } catch (Throwable t) { CrashLog.save(c, t); }
  }

  static void pushInner(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, VolumeWidget.class));
    if (ids == null || ids.length == 0) return;

    /* 데이터 → 로컬 (인스턴스 루프 밖에서 1회 파싱) */
    String[] label = new String[LB.length];
    int[] cur = new int[LB.length];
    int[] tgt = new int[LB.length];
    boolean has = false;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) {
        JSONArray v = new JSONObject(raw).getJSONArray("v");
        has = true;
        for (int i = 0; i < LB.length; i++) {
          if (i < v.length()) {
            JSONArray r = v.getJSONArray(i);
            label[i] = r.getString(0) + "  " + r.getInt(1) + "/" + r.getInt(2);
            cur[i] = Math.min(r.getInt(1), r.getInt(2));
            tgt[i] = Math.max(1, r.getInt(2));
          } else { label[i] = ""; cur[i] = 0; tgt[i] = 1; }
        }
      }
    } catch (Exception e) { has = false; }

    PendingIntent pi = PendingIntent.getActivity(c, 0,
        new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

    for (int wi = 0; wi < ids.length; wi++) {
      int id = ids[wi];
      RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_volume);
      rv.setTextViewText(R.id.vhd, "WEEKLY SETS" + WDate.staleTag(c));
      if (!has) {
        rv.setTextViewText(R.id.l1, "Open PLUS2.5 once to sync");
        for (int i = 1; i < LB.length; i++) rv.setTextViewText(LB[i], "");
      } else {
        for (int i = 0; i < LB.length; i++) {
          rv.setTextViewText(LB[i], label[i]);
          rv.setProgressBar(BR[i], tgt[i], cur[i], false);
        }
      }
      rv.setOnClickPendingIntent(R.id.root, pi);
      int cbg = WCfg.bg(c, id), cop = WCfg.op(c, id);
      boolean cl = !WCfg.lightText(cbg, cop, WCfg.txMode(c, id));
      WCfg.paint(rv, cbg, cop);
      applyTheme(rv, cl);
      m.updateAppWidget(id, rv);
    }
  }

  static void applyTheme(RemoteViews rv, boolean lt) {
    rv.setTextColor(R.id.vhd, WTheme.head(lt));
    WTheme.tint(rv, LB, WTheme.label(lt));
  }
}
