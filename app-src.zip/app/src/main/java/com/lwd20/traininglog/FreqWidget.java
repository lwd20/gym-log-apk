package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class FreqWidget extends AppWidgetProvider {
  static final int[] FL = {R.id.fl0, R.id.fl1, R.id.fl2, R.id.fl3, R.id.fl4};
  static final int[] FC = {R.id.fc0, R.id.fc1, R.id.fc2, R.id.fc3, R.id.fc4};
  static final String[] DEF = {"C", "B", "S", "L", "A"};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, FreqWidget.class));
    if (ids == null || ids.length == 0) return;
    RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_freq);
    JSONArray arr = null;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) arr = new JSONObject(raw).optJSONArray("c");
    } catch (Exception e) {}
    for (int i = 0; i < 5; i++) {
      String lb = DEF[i];
      String n = "-";
      try {
        if (arr != null && i < arr.length()) {
          JSONArray r = arr.getJSONArray(i);
          lb = r.getString(0);
          int f = r.getInt(1);
          n = String.valueOf(f);
          rv.setTextColor(FC[i], f > 0 ? 0xFFE3B95A : 0xFF4A4436);
        }
      } catch (Exception e) {}
      rv.setTextViewText(FL[i], lb);
      rv.setTextViewText(FC[i], n);
    }
    Intent it = new Intent(c, MainActivity.class);
    rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE));
    m.updateAppWidget(ids, rv);
  }
}
