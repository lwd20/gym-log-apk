package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class FreqWidget extends AppWidgetProvider {
  static final int[] FL = {R.id.fl0, R.id.fl1, R.id.fl2, R.id.fl3, R.id.fl4, R.id.fl5};
  static final int[] FC = {R.id.fc0, R.id.fc1, R.id.fc2, R.id.fc3, R.id.fc4, R.id.fc5};
  static final String[] DEF = {"가슴", "등", "어깨", "하체", "팔", "유산소"};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    CrashLog.install(c);
    try { pushInner(c); } catch (Throwable t) { CrashLog.save(c, t); }
  }

  static void pushInner(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, FreqWidget.class));
    if (ids == null || ids.length == 0) return;

    String[] lb = new String[FL.length];
    String[] nv = new String[FL.length];
    boolean[] on = new boolean[FL.length];
    JSONArray arr = null;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) arr = new JSONObject(raw).optJSONArray("c");
    } catch (Exception e) {}
    for (int i = 0; i < FL.length; i++) {
      lb[i] = DEF[i]; nv[i] = "-"; on[i] = false;
      try {
        if (arr != null && i < arr.length()) {
          JSONArray r = arr.getJSONArray(i);
          lb[i] = r.getString(0);
          int f = r.getInt(1);
          nv[i] = String.valueOf(f);
          on[i] = f > 0;
        }
      } catch (Exception e) {}
    }

    PendingIntent pi = PendingIntent.getActivity(c, 0,
        new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);

    for (int wi = 0; wi < ids.length; wi++) {
      int id = ids[wi];
      RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_freq);
      rv.setTextViewText(R.id.fhd, "SESSIONS / WEEK" + WDate.staleTag(c));
      for (int i = 0; i < FL.length; i++) {
        rv.setTextViewText(FL[i], lb[i]);
        rv.setTextViewText(FC[i], nv[i]);
      }
      rv.setOnClickPendingIntent(R.id.root, pi);
      int cbg = WCfg.bg(c, id), cop = WCfg.op(c, id);
      boolean cl = !WCfg.lightText(cbg, cop, WCfg.txMode(c, id));
      WCfg.paint(rv, cbg, cop);
      applyTheme(rv, cl);
      for (int i = 0; i < FL.length; i++)
        if (on[i]) rv.setTextColor(FC[i], 0xFFE3B95A);
        else rv.setTextColor(FC[i], cl ? 0xFFB9AE93 : 0xFF4A4436);
      m.updateAppWidget(id, rv);
    }
  }

  static void applyTheme(RemoteViews rv, boolean lt) {
    rv.setTextColor(R.id.fhd, WTheme.head(lt));
    WTheme.tint(rv, FL, WTheme.head(lt));
    WTheme.tint(rv, FC, WTheme.value(lt));
  }
}
