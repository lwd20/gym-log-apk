package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class WeekWidget extends AppWidgetProvider {
  static final int[] DD = {R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6};
  static final int[] PL = {R.id.pl0, R.id.pl1, R.id.pl2, R.id.pl3, R.id.pl4, R.id.pl5};
  static final int[][] CE = {
    {R.id.w00, R.id.w01, R.id.w02, R.id.w03, R.id.w04, R.id.w05, R.id.w06},
    {R.id.w10, R.id.w11, R.id.w12, R.id.w13, R.id.w14, R.id.w15, R.id.w16},
    {R.id.w20, R.id.w21, R.id.w22, R.id.w23, R.id.w24, R.id.w25, R.id.w26},
    {R.id.w30, R.id.w31, R.id.w32, R.id.w33, R.id.w34, R.id.w35, R.id.w36},
    {R.id.w40, R.id.w41, R.id.w42, R.id.w43, R.id.w44, R.id.w45, R.id.w46},
    {R.id.w50, R.id.w51, R.id.w52, R.id.w53, R.id.w54, R.id.w55, R.id.w56}
  };
  static final String[] DAY = {"M", "T", "W", "T", "F", "S", "S"};
  static final String[] PART = {"\uac00\uc2b4", "\ub4f1", "\uc5b4\uae68", "\ud558\uccb4", "\ud314", "\uc720\uc0b0\uc18c"};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, WeekWidget.class));
    if (ids == null || ids.length == 0) return;
    RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_week);
    int today = -1;
    JSONArray w = null;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) {
        JSONObject o = new JSONObject(raw);
        today = o.optInt("t", -1);
        w = o.getJSONArray("w");
      }
    } catch (Exception e) {}
    boolean[][] done = new boolean[6][7];
    for (int d = 0; d < 7; d++) {
      String parts = "";
      try { if (w != null) parts = w.getString(d); } catch (Exception e) {}
      for (int p = 0; p < 6; p++) done[p][d] = parts.contains(PART[p]);
    }
    for (int d = 0; d < 7; d++) rv.setTextViewText(DD[d], DAY[d]);
    for (int p = 0; p < 6; p++) rv.setTextViewText(PL[p], PART[p]);
    Intent it = new Intent(c, MainActivity.class);
    rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE));
        for (int wi = 0; wi < ids.length; wi++) {
      int id = ids[wi];
      int cbg = WCfg.bg(c, id), cop = WCfg.op(c, id);
      boolean cl = !WCfg.lightText(cbg, cop, WCfg.txMode(c, id));
      WCfg.paint(rv, cbg, cop);
      applyTheme(rv, cl);
      paintGrid(rv, cl, today, done);
      m.updateAppWidget(id, rv);
    }
  }

  static void applyTheme(RemoteViews rv, boolean lt) {
    rv.setTextColor(R.id.whd, WTheme.head(lt));
    WTheme.tint(rv, PL, WTheme.head(lt));
  }

  static void paintGrid(RemoteViews rv, boolean lt, int today, boolean[][] done) {
    for (int d = 0; d < 7; d++) {
      if (d == today) {
        rv.setInt(DD[d], "setBackgroundResource", WTheme.today(lt));
        rv.setTextColor(DD[d], WTheme.todayText(lt));
      } else {
        rv.setInt(DD[d], "setBackgroundResource", 0);
        rv.setTextColor(DD[d], WTheme.dim(lt));
      }
    }
    for (int p = 0; p < 6; p++) {
      for (int d = 0; d < 7; d++) {
        rv.setInt(CE[p][d], "setBackgroundResource",
            done[p][d] ? WTheme.dotOn(lt) : WTheme.dotOff(lt));
      }
    }
  }
}
