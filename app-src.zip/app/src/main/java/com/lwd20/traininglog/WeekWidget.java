package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class WeekWidget extends AppWidgetProvider {
  static final int[] DD = {R.id.d0, R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6};
  static final int[] PP = {R.id.p0, R.id.p1, R.id.p2, R.id.p3, R.id.p4, R.id.p5, R.id.p6};
  static final String[] DAY = {"M", "T", "W", "T", "F", "S", "S"};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, WeekWidget.class));
    if (ids == null || ids.length == 0) return;
    RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_week);
    int today = -1;
    JSONArray w = null;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) {
        JSONObject o = new JSONObject(raw);
        today = o.optInt("t", -1);
        w = o.getJSONArray("w");
      }
    } catch (Exception e) {}
    for (int i = 0; i < 7; i++) {
      rv.setTextViewText(DD[i], DAY[i]);
      if (i == today) {
        rv.setInt(DD[i], "setBackgroundResource", R.drawable.wg_today);
        rv.setTextColor(DD[i], 0xFF1A1200);
      } else {
        rv.setInt(DD[i], "setBackgroundResource", 0);
        rv.setTextColor(DD[i], 0xFF8F887C);
      }
      String parts = "";
      try { if (w != null) parts = w.getString(i); } catch (Exception e) {}
      if (parts == null || parts.length() == 0) {
        rv.setTextViewText(PP[i], "·");
        rv.setTextColor(PP[i], 0xFF4A4436);
      } else {
        rv.setTextViewText(PP[i], parts.replace("\u00b7", "\n"));
        rv.setTextColor(PP[i], 0xFFCFA648);
      }
    }
    Intent it = new Intent(c, MainActivity.class);
    rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE));
    m.updateAppWidget(ids, rv);
  }
}
