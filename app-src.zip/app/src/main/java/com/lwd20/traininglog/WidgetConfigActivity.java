package com.lwd20.traininglog;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** 홈에서 위젯 길게 눌러 진입 — 배경 색(RGB/HEX 직접 입력)·투명도·글자 테마 */
public class WidgetConfigActivity extends Activity {

  private static final int C_BG    = 0xFF0E0C0A;
  private static final int C_CARD  = 0xFF17120D;
  private static final int C_EDGE  = 0xFF2B2418;
  private static final int C_INSET = 0xFF0B0906;
  private static final int C_LAB   = 0xFF9A8A63;
  private static final int C_DIM   = 0xFF6E6552;
  private static final int C_GOLD  = 0xFFE3B95A;
  private static final int C_TEXT  = 0xFFE6DCC4;

  private int wid = AppWidgetManager.INVALID_APPWIDGET_ID;
  private int bg = 0xFF1A140C;
  private int op = 100;
  private int tx = 0; /* 0 자동, 1 밝은 글자, 2 어두운 글자 */

  private boolean lock = false;

  private View pvBox;
  private TextView pvLabel, pvValue, opVal;
  private SeekBar sbR, sbG, sbB, sbO;
  private EditText edR, edG, edB, edHex;
  private Button[] txBtns = new Button[3];

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    setResult(RESULT_CANCELED);
    try {
      Intent it = getIntent();
      if (it != null && it.getExtras() != null) {
        wid = it.getExtras().getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
      }
    } catch (Exception e) {}
    if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }
    try {
      bg = WCfg.bg(this, wid);
      op = WCfg.op(this, wid);
      tx = WCfg.txMode(this, wid);
    } catch (Exception e) {}
    CrashLog.install(this);
    try {
      setContentView(buildUi());
      apply(null);
    } catch (Throwable t) {
      CrashLog.save(this, t);
      finish();
    }
  }

  private int dp(float v) {
    return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
  }

  private GradientDrawable rounded(int fill, int stroke, float rad) {
    GradientDrawable g = new GradientDrawable();
    g.setColor(fill);
    g.setCornerRadius(dp(rad));
    if (stroke != 0) g.setStroke(dp(1), stroke);
    return g;
  }

  /* ── UI 구성 ─────────────────────────────────── */

  private View buildUi() {
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackgroundColor(C_BG);

    /* 헤더 바 */
    LinearLayout bar = new LinearLayout(this);
    bar.setOrientation(LinearLayout.HORIZONTAL);
    bar.setGravity(Gravity.CENTER_VERTICAL);
    bar.setPadding(dp(20), 0, dp(8), 0);
    bar.setLayoutParams(new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
    TextView title = new TextView(this);
    title.setText("\uc704\uc82f \uc2a4\ud0c0\uc77c");
    title.setTextSize(18);
    title.setTextColor(C_TEXT);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    bar.addView(title);
    Button save = new Button(this);
    save.setText("\uc800\uc7a5");
    save.setAllCaps(false);
    save.setTextSize(14);
    save.setTextColor(C_GOLD);
    save.setBackground(rounded(0x00000000, 0, 0));
    save.setPadding(dp(16), 0, dp(16), 0);
    save.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) { saveAndFinish(); }
    });
    bar.addView(save);
    root.addView(bar);

    View div = new View(this);
    div.setBackgroundColor(C_EDGE);
    div.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
    root.addView(div);

    /* 스크롤 본문 */
    ScrollView sv = new ScrollView(this);
    sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    LinearLayout body = new LinearLayout(this);
    body.setOrientation(LinearLayout.VERTICAL);
    body.setPadding(dp(16), dp(16), dp(16), dp(24));
    sv.addView(body);
    root.addView(sv);

    /* 미리보기 카드 */
    LinearLayout cPrev = card(body, "\ubbf8\ub9ac\ubcf4\uae30");
    LinearLayout pv = new LinearLayout(this);
    pv.setOrientation(LinearLayout.VERTICAL);
    pv.setPadding(dp(16), dp(14), dp(16), dp(14));
    pvLabel = new TextView(this);
    pvLabel.setText("\uc5b4\uae68");
    pvLabel.setTextSize(13);
    pvValue = new TextView(this);
    pvValue.setText("20 / 20 \uc138\ud2b8");
    pvValue.setTextSize(17);
    pvValue.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
    pvValue.setPadding(0, dp(4), 0, 0);
    pv.addView(pvLabel);
    pv.addView(pvValue);
    LinearLayout.LayoutParams pvp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(88));
    pvp.setMargins(dp(14), dp(4), dp(14), dp(14));
    pv.setLayoutParams(pvp);
    pvBox = pv;
    cPrev.addView(pv);

    /* 배경 색 카드 */
    LinearLayout cCol = card(body, "\ubc30\uacbd \uc0c9");
    LinearLayout hexRow = new LinearLayout(this);
    hexRow.setOrientation(LinearLayout.HORIZONTAL);
    hexRow.setGravity(Gravity.CENTER_VERTICAL);
    hexRow.setPadding(dp(14), dp(2), dp(14), dp(8));
    TextView hexLb = new TextView(this);
    hexLb.setText("HEX");
    hexLb.setTextSize(12);
    hexLb.setTextColor(C_DIM);
    hexLb.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
    hexLb.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    hexRow.addView(hexLb);
    edHex = makeEdit(false);
    LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.WRAP_CONTENT);
    edHex.setLayoutParams(hlp);
    hexRow.addView(edHex);
    cCol.addView(hexRow);
    edHex.addTextChangedListener(new Watch() {
      @Override void changed(String t) {
        if (lock) return;
        String h = t.trim().replace("#", "");
        if (h.length() != 6) return;
        try {
          int c = (int) Long.parseLong(h, 16) | 0xFF000000;
          bg = c;
          apply(edHex);
        } catch (Exception e) {}
      }
    });
    sbR = channel(cCol, "R", 0);
    sbG = channel(cCol, "G", 1);
    sbB = channel(cCol, "B", 2);

    /* 투명도 카드 */
    LinearLayout cOp = card(body, "\ud22c\uba85\ub3c4");
    LinearLayout opRow = new LinearLayout(this);
    opRow.setOrientation(LinearLayout.HORIZONTAL);
    opRow.setGravity(Gravity.CENTER_VERTICAL);
    opRow.setPadding(dp(14), dp(2), dp(14), dp(12));
    sbO = new SeekBar(this);
    sbO.setMax(100);
    sbO.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    sbO.setOnSeekBarChangeListener(new Seek() {
      @Override void moved(int v, boolean user) {
        if (!user || lock) return;
        op = v;
        apply(sbO);
      }
    });
    opVal = new TextView(this);
    opVal.setTextColor(C_GOLD);
    opVal.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
    opVal.setTextSize(13);
    opVal.setPadding(dp(12), 0, 0, 0);
    opVal.setMinWidth(dp(46));
    opVal.setGravity(Gravity.END);
    opRow.addView(sbO);
    opRow.addView(opVal);
    cOp.addView(opRow);

    /* 글자 카드 */
    LinearLayout cTx = card(body, "\uae00\uc790");
    LinearLayout txRow = new LinearLayout(this);
    txRow.setOrientation(LinearLayout.HORIZONTAL);
    txRow.setPadding(dp(14), dp(2), dp(14), dp(14));
    String[] names = {"\uc790\ub3d9", "\ubc1d\uac8c", "\uc5b4\ub461\uac8c"};
    for (int i = 0; i < 3; i++) {
      final int idx = i;
      Button btn = new Button(this);
      btn.setText(names[i]);
      btn.setAllCaps(false);
      btn.setTextSize(13);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
      if (i > 0) lp.leftMargin = dp(8);
      btn.setLayoutParams(lp);
      btn.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) { tx = idx; apply(null); }
      });
      txBtns[i] = btn;
      txRow.addView(btn);
    }
    cTx.addView(txRow);

    /* 최근 오류 카드 — 크래시 로그가 있을 때만 표시 */
    final String crash = CrashLog.read(this);
    if (crash != null) {
      final LinearLayout cEr = card(body, "\ucd5c\uadfc \uc624\ub958 (\uae38\uac8c \ub20c\ub7ec \ubcf5\uc0ac)");
      TextView tvE = new TextView(this);
      tvE.setText(crash);
      tvE.setTextSize(10);
      tvE.setTextColor(0xFFB08A8A);
      tvE.setTypeface(Typeface.MONOSPACE);
      tvE.setTextIsSelectable(true);
      tvE.setPadding(dp(14), dp(4), dp(14), dp(8));
      cEr.addView(tvE);
      Button clr = new Button(this);
      clr.setText("\uc9c0\uc6b0\uae30");
      clr.setAllCaps(false);
      clr.setTextSize(12);
      clr.setTextColor(C_DIM);
      clr.setBackground(rounded(0x00000000, 0, 0));
      clr.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          CrashLog.clear(WidgetConfigActivity.this);
          cEr.setVisibility(View.GONE);
        }
      });
      cEr.addView(clr);
    }

    return root;
  }

  /* 카드 컨테이너 + 섹션 제목 */
  private LinearLayout card(LinearLayout parent, String name) {
    TextView h = new TextView(this);
    h.setText(name);
    h.setTextSize(12);
    h.setTextColor(C_LAB);
    h.setPadding(dp(6), dp(6), 0, dp(8));
    parent.addView(h);
    LinearLayout c = new LinearLayout(this);
    c.setOrientation(LinearLayout.VERTICAL);
    c.setBackground(rounded(C_CARD, C_EDGE, 12));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    lp.bottomMargin = dp(16);
    c.setLayoutParams(lp);
    parent.addView(c);
    return c;
  }

  /* 채널 행: 라벨 + 슬라이더 + 숫자 입력 */
  private SeekBar channel(LinearLayout parent, String name, final int chIdx) {
    LinearLayout r = new LinearLayout(this);
    r.setOrientation(LinearLayout.HORIZONTAL);
    r.setGravity(Gravity.CENTER_VERTICAL);
    r.setPadding(dp(14), dp(2), dp(14), dp(6));
    TextView lb = new TextView(this);
    lb.setText(name);
    lb.setTextSize(12);
    lb.setTextColor(C_DIM);
    lb.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
    lb.setMinWidth(dp(22));
    r.addView(lb);
    final SeekBar sb = new SeekBar(this);
    sb.setMax(255);
    sb.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    r.addView(sb);
    final EditText ed = makeEdit(true);
    LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT);
    elp.leftMargin = dp(10);
    ed.setLayoutParams(elp);
    r.addView(ed);
    parent.addView(r);
    if (chIdx == 0) edR = ed; else if (chIdx == 1) edG = ed; else edB = ed;
    sb.setOnSeekBarChangeListener(new Seek() {
      @Override void moved(int v, boolean user) {
        if (!user || lock) return;
        setChannel(chIdx, v);
        apply(sb);
      }
    });
    ed.addTextChangedListener(new Watch() {
      @Override void changed(String t) {
        if (lock) return;
        try {
          int v = Integer.parseInt(t.trim());
          if (v < 0) v = 0; if (v > 255) v = 255;
          setChannel(chIdx, v);
          apply(ed);
        } catch (Exception e) {}
      }
    });
    return sb;
  }

  private EditText makeEdit(boolean number) {
    EditText ed = new EditText(this);
    ed.setSingleLine(true);
    ed.setTextSize(13);
    ed.setTextColor(C_GOLD);
    ed.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
    ed.setGravity(Gravity.CENTER);
    ed.setBackground(rounded(C_INSET, C_EDGE, 6));
    ed.setPadding(dp(10), dp(8), dp(10), dp(8));
    ed.setInputType(number ? InputType.TYPE_CLASS_NUMBER
        : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));
    return ed;
  }

  private void setChannel(int ch, int v) {
    int r = Color.red(bg), g = Color.green(bg), b2 = Color.blue(bg);
    if (ch == 0) r = v; else if (ch == 1) g = v; else b2 = v;
    bg = Color.argb(255, r, g, b2);
  }

  /* ── 상태 → 화면 일괄 반영 (src는 갱신 생략 대상) ── */
  private void apply(View src) {
    lock = true;
    try {
      int r = Color.red(bg), g = Color.green(bg), b2 = Color.blue(bg);
      if (sbR != null && src != sbR) sbR.setProgress(r);
      if (sbG != null && src != sbG) sbG.setProgress(g);
      if (sbB != null && src != sbB) sbB.setProgress(b2);
      if (edR != null && src != edR) edR.setText(String.valueOf(r));
      if (edG != null && src != edG) edG.setText(String.valueOf(g));
      if (edB != null && src != edB) edB.setText(String.valueOf(b2));
      if (edHex != null && src != edHex)
        edHex.setText(String.format("#%02X%02X%02X", r, g, b2));
      if (sbO != null && src != sbO) sbO.setProgress(op);
      if (opVal != null) opVal.setText(op + "%");

      if (pvBox != null) {
        GradientDrawable gd = rounded(
            Color.argb(Math.round(op * 255f / 100f), r, g, b2), C_EDGE, 14);
        pvBox.setBackground(gd);
        boolean lightText = WCfg.lightText(bg, op, tx);
        if (pvLabel != null) pvLabel.setTextColor(lightText ? 0xFFC9BFA8 : 0xFF433A22);
        if (pvValue != null) pvValue.setTextColor(lightText ? 0xFFE3B95A : 0xFF5A3E00);
      }
      for (int i = 0; i < 3; i++) {
        Button bt = txBtns[i];
        if (bt == null) continue;
        boolean on = (tx == i);
        bt.setBackground(rounded(on ? 0xFF2E2410 : C_INSET, on ? 0xFF8F7022 : C_EDGE, 8));
        bt.setTextColor(on ? C_GOLD : C_DIM);
      }
    } catch (Exception e) {
    } finally {
      lock = false;
    }
  }

  private void saveAndFinish() {
    try {
      getSharedPreferences("widget", 0).edit()
        .putInt("bg_" + wid, bg)
        .putInt("op_" + wid, op)
        .putInt("tx_" + wid, tx)
        .apply();
      VolumeWidget.push(this);
      WeekWidget.push(this);
      FreqWidget.push(this);
      LastWidget.push(this);
      TodayWidget.push(this);
    } catch (Exception e) {}
    Intent out = new Intent();
    out.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid);
    setResult(RESULT_OK, out);
    finish();
  }

  /* 리스너 축약 베이스 — 본문 예외는 전부 흡수 */
  private abstract static class Seek implements SeekBar.OnSeekBarChangeListener {
    abstract void moved(int v, boolean user);
    @Override public void onProgressChanged(SeekBar s, int v, boolean u) { try { moved(v, u); } catch (Exception e) {} }
    @Override public void onStartTrackingTouch(SeekBar s) {}
    @Override public void onStopTrackingTouch(SeekBar s) {}
  }
  private abstract static class Watch implements TextWatcher {
    abstract void changed(String t);
    @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
    @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
    @Override public void afterTextChanged(Editable e) { try { changed(e == null ? "" : e.toString()); } catch (Exception ex) {} }
  }
}
