package com.lwd20.traininglog;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** 홈 화면에서 위젯을 길게 눌러 "설정"으로 진입 — 위젯별 배경색·투명도·글자 테마 */
public class WidgetConfigActivity extends Activity {

  private int wid = AppWidgetManager.INVALID_APPWIDGET_ID;
  private int bg = 0xFF1A140C;
  private int op = 100;
  private int tx = 0; /* 0 자동, 1 밝은 글자, 2 어두운 글자 */

  private View preview;
  private TextView pvLabel, pvValue, opLabel;
  private SeekBar sbR, sbG, sbB, sbO;
  private Button[] txBtns = new Button[3];

  private static final int[] PRESETS = {
    0xFF1A140C, 0xFF0E0C0A, 0xFF2A2118, 0xFF3A2F1A,
    0xFF14181A, 0xFF101A2B, 0xFF0F2018, 0xFF1F1F23,
    0xFFF2EDE1, 0xFFE8DCC8, 0xFFD8CBB4, 0xFFFFFFFF
  };

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    setResult(RESULT_CANCELED);

    Intent it = getIntent();
    if (it != null && it.getExtras() != null) {
      wid = it.getExtras().getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
    }
    if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }

    load();
    setContentView(buildUi());
    syncUi();
  }

  private int dp(float v) {
    return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
  }

  private void load() {
    SharedPreferences sp = getSharedPreferences("widget", 0);
    bg = sp.getInt("bg_" + wid, WCfg.defBg(this));
    op = sp.getInt("op_" + wid, WCfg.defOp(this));
    tx = sp.getInt("tx_" + wid, 0);
  }

  private View buildUi() {
    ScrollView sv = new ScrollView(this);
    sv.setBackgroundColor(0xFF0E0C0A);

    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(20), dp(24), dp(20), dp(24));
    sv.addView(root);

    root.addView(head("WIDGET STYLE"));

    /* 미리보기 */
    preview = new View(this);
    LinearLayout pvWrap = new LinearLayout(this);
    pvWrap.setOrientation(LinearLayout.VERTICAL);
    pvWrap.setPadding(dp(16), dp(14), dp(16), dp(14));
    pvLabel = new TextView(this);
    pvLabel.setText("어깨");
    pvLabel.setTextSize(13);
    pvValue = new TextView(this);
    pvValue.setText("20 / 20 세트");
    pvValue.setTextSize(17);
    pvValue.setPadding(0, dp(4), 0, 0);
    pvWrap.addView(pvLabel);
    pvWrap.addView(pvValue);
    LinearLayout.LayoutParams pvp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(92));
    pvp.bottomMargin = dp(20);
    pvWrap.setLayoutParams(pvp);
    root.addView(pvWrap);
    preview = pvWrap;

    /* 프리셋 */
    root.addView(label("프리셋"));
    LinearLayout row = null;
    for (int i = 0; i < PRESETS.length; i++) {
      if (i % 6 == 0) {
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.bottomMargin = dp(8);
        row.setLayoutParams(rp);
        root.addView(row);
      }
      final int col = PRESETS[i];
      View sw = new View(this);
      GradientDrawable g = new GradientDrawable();
      g.setShape(GradientDrawable.RECTANGLE);
      g.setCornerRadius(dp(6));
      g.setColor(col);
      g.setStroke(dp(1), 0xFF4A3C1C);
      sw.setBackground(g);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
      lp.rightMargin = dp(8);
      sw.setLayoutParams(lp);
      sw.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) {
          bg = col;
          sbR.setProgress(Color.red(col));
          sbG.setProgress(Color.green(col));
          sbB.setProgress(Color.blue(col));
          syncUi();
        }
      });
      row.addView(sw);
    }

    /* RGB */
    root.addView(label("직접 조색"));
    sbR = slider(root, "R", 255);
    sbG = slider(root, "G", 255);
    sbB = slider(root, "B", 255);

    /* 투명도 */
    opLabel = label("투명도 " + op + "%");
    root.addView(opLabel);
    sbO = new SeekBar(this);
    sbO.setMax(100);
    sbO.setProgress(op);
    LinearLayout.LayoutParams op2 = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    op2.bottomMargin = dp(16);
    sbO.setLayoutParams(op2);
    sbO.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
      @Override public void onProgressChanged(SeekBar s, int v, boolean u) {
        op = v; opLabel.setText("투명도 " + v + "%"); syncUi();
      }
      @Override public void onStartTrackingTouch(SeekBar s) {}
      @Override public void onStopTrackingTouch(SeekBar s) {}
    });
    root.addView(sbO);

    /* 글자 테마 */
    root.addView(label("글자"));
    LinearLayout txRow = new LinearLayout(this);
    txRow.setOrientation(LinearLayout.HORIZONTAL);
    String[] names = {"자동", "밝게", "어둡게"};
    for (int i = 0; i < 3; i++) {
      final int idx = i;
      Button btn = new Button(this);
      btn.setText(names[i]);
      btn.setAllCaps(false);
      btn.setTextSize(12);
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
      lp.rightMargin = dp(8);
      btn.setLayoutParams(lp);
      btn.setOnClickListener(new View.OnClickListener() {
        @Override public void onClick(View v) { tx = idx; syncUi(); }
      });
      txBtns[i] = btn;
      txRow.addView(btn);
    }
    LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    trp.bottomMargin = dp(24);
    txRow.setLayoutParams(trp);
    root.addView(txRow);

    /* 저장 */
    Button save = new Button(this);
    save.setText("저장");
    save.setAllCaps(false);
    save.setTextSize(14);
    GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
        new int[]{0xFFDDBB59, 0xFFA9862B});
    sg.setCornerRadius(dp(6));
    save.setBackground(sg);
    save.setTextColor(0xFF1A1200);
    save.setLayoutParams(new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
    save.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) { saveAndFinish(); }
    });
    root.addView(save);

    return sv;
  }

  private TextView head(String t) {
    TextView tv = new TextView(this);
    tv.setText(t);
    tv.setTextSize(13);
    tv.setTextColor(0xFFCFA648);
    tv.setLetterSpacing(0.2f);
    tv.setPadding(0, 0, 0, dp(16));
    return tv;
  }

  private TextView label(String t) {
    TextView tv = new TextView(this);
    tv.setText(t);
    tv.setTextSize(11);
    tv.setTextColor(0xFF9A8A63);
    tv.setPadding(0, dp(4), 0, dp(8));
    return tv;
  }

  private SeekBar slider(LinearLayout parent, String name, int max) {
    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setGravity(Gravity.CENTER_VERTICAL);
    TextView tv = new TextView(this);
    tv.setText(name);
    tv.setTextSize(11);
    tv.setTextColor(0xFF8F887C);
    tv.setWidth(dp(20));
    row.addView(tv);
    SeekBar sb = new SeekBar(this);
    sb.setMax(max);
    sb.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
      @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
        if (!fromUser) return;
        bg = Color.argb(255, sbR.getProgress(), sbG.getProgress(), sbB.getProgress());
        syncUi();
      }
      @Override public void onStartTrackingTouch(SeekBar s) {}
      @Override public void onStopTrackingTouch(SeekBar s) {}
    });
    row.addView(sb);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    lp.bottomMargin = dp(4);
    row.setLayoutParams(lp);
    parent.addView(row);
    return sb;
  }

  private void syncUi() {
    if (sbR != null && sbR.getProgress() != Color.red(bg)) sbR.setProgress(Color.red(bg));
    if (sbG != null && sbG.getProgress() != Color.green(bg)) sbG.setProgress(Color.green(bg));
    if (sbB != null && sbB.getProgress() != Color.blue(bg)) sbB.setProgress(Color.blue(bg));

    GradientDrawable g = new GradientDrawable();
    g.setCornerRadius(dp(14));
    g.setColor(Color.argb(Math.round(op * 255f / 100f), Color.red(bg), Color.green(bg), Color.blue(bg)));
    preview.setBackground(g);

    boolean lightText = WCfg.lightText(bg, op, tx);
    pvLabel.setTextColor(lightText ? 0xFF9A8A63 : 0xFF433A22);
    pvValue.setTextColor(lightText ? 0xFFE3B95A : 0xFF5A3E00);

    for (int i = 0; i < 3; i++) {
      boolean on = (tx == i);
      GradientDrawable bgd = new GradientDrawable();
      bgd.setCornerRadius(dp(6));
      bgd.setColor(on ? 0xFF3A2F1A : 0xFF1C1710);
      bgd.setStroke(dp(1), on ? 0xFFCFA648 : 0xFF3A342A);
      txBtns[i].setBackground(bgd);
      txBtns[i].setTextColor(on ? 0xFFE3B95A : 0xFF8F887C);
    }
  }

  private void saveAndFinish() {
    getSharedPreferences("widget", 0).edit()
      .putInt("bg_" + wid, bg)
      .putInt("op_" + wid, op)
      .putInt("tx_" + wid, tx)
      .apply();

    AppWidgetManager m = AppWidgetManager.getInstance(this);
    VolumeWidget.push(this);
    WeekWidget.push(this);
    FreqWidget.push(this);
    LastWidget.push(this);
    TodayWidget.push(this);

    Intent out = new Intent();
    out.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid);
    setResult(RESULT_OK, out);
    finish();
  }
}
