package com.lwd20.traininglog;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;
import org.json.JSONObject;

/** 위젯 인스턴스별 스타일(배경색·투명도·글자) — 앱 설정값을 기본으로 사용 */
public class WCfg {

  /** 앱(⋯ 설정)에서 내려온 기본 투명도 */
  public static int defOp(Context c) {
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) return new JSONObject(raw).optInt("o", 100);
    } catch (Exception e) {}
    return 100;
  }

  /** 기본 배경색 — 앱 테마 브론즈 */
  public static int defBg(Context c) {
    return 0xFF1A140C;
  }

  public static int bg(Context c, int wid) {
    return c.getSharedPreferences("widget", 0).getInt("bg_" + wid, defBg(c));
  }

  public static int op(Context c, int wid) {
    return c.getSharedPreferences("widget", 0).getInt("op_" + wid, defOp(c));
  }

  public static int txMode(Context c, int wid) {
    SharedPreferences sp = c.getSharedPreferences("widget", 0);
    if (sp.contains("tx_" + wid)) return sp.getInt("tx_" + wid, 0);
    /* 위젯별 설정 전이면 앱의 전역 글자 테마를 따름 */
    try {
      String raw = sp.getString("data", null);
      if (raw != null) {
        JSONObject o = new JSONObject(raw);
        if (o.has("tm")) {           /* 0=자동 1=밝은 글자 2=어두운 글자 */
          int t = o.optInt("tm", 0);
          if (t >= 0 && t <= 2) return t;
        }
        if (o.optInt("k", 0) == 1) return 2;   /* 구버전 스냅샷 호환 */
      }
    } catch (Exception e) {}
    return 0;
  }

  /** true = 밝은 글자(어두운 배경용) */
  public static boolean lightText(int bg, int op, int txMode) {
    if (txMode == 1) return true;
    if (txMode == 2) return false;
    /* 자동: 배경이 투명할수록 배경화면이 드러나므로 밝다고 가정 */
    double lum = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0;
    double eff = lum * (op / 100.0) + 0.85 * (1.0 - (op / 100.0));
    return eff < 0.5;
  }

  /** 배경 이미지에 색·투명도 적용 */
  public static void paint(RemoteViews rv, int bg, int op) {
    rv.setInt(R.id.bgimg, "setColorFilter", 0xFF000000 | (bg & 0x00FFFFFF));
    rv.setInt(R.id.bgimg, "setImageAlpha", Math.round(op * 255f / 100f));
  }
}
