package com.lwd20.traininglog;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class TodayWidget extends AppWidgetProvider {
  static final int[] N = {R.id.tdn0, R.id.tdn1, R.id.tdn2, R.id.tdn3, R.id.tdn4, R.id.tdn5};
  static final int[] V = {R.id.tdv0, R.id.tdv1, R.id.tdv2, R.id.tdv3, R.id.tdv4, R.id.tdv5};
  static final int[] S = {R.id.tds0, R.id.tds1, R.id.tds2, R.id.tds3, R.id.tds4, R.id.tds5};

  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c); }

  static void push(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, TodayWidget.class));
    if (ids == null || ids.length == 0) return;
    RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_today);
    JSONArray a = null;
    try {
      String raw = c.getSharedPreferences("widget", 0).getString("data", null);
      if (raw != null) a = new JSONObject(raw).optJSONArray("td");
    } catch (Exception e) {}
    int n = a == null ? 0 : a.length();
    rv.setTextViewText(R.id.root_cnt, n > 0 ? String.valueOf(n) : "");
    for (int i = 0; i < 6; i++) {
      if (i < n) {
        try {
          JSONArray r = a.getJSONArray(i);
          rv.setTextViewText(N[i], r.getString(0));
          rv.setTextViewText(V[i], r.getString(1));
          rv.setTextViewText(S[i], tail(r, 2));
          rv.setViewVisibility(N[i], View.VISIBLE);
          rv.setViewVisibility(V[i], View.VISIBLE);
          rv.setViewVisibility(S[i], View.VISIBLE);
          continue;
        } catch (Exception e) {}
      }
      rv.setViewVisibility(N[i], View.GONE);
      rv.setViewVisibility(V[i], View.GONE);
      rv.setViewVisibility(S[i], View.GONE);
    }
    rv.setViewVisibility(R.id.root_empty, n == 0 ? View.VISIBLE : View.GONE);
    if (n == 0) rv.setTextViewText(R.id.root_empty, "오늘 기록 없음");
    Intent it = new Intent(c, MainActivity.class);
    rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE));
    for (int wi = 0; wi < ids.length; wi++) {
      int id = ids[wi];
      int cbg = WCfg.bg(c, id), cop = WCfg.op(c, id);
      boolean cl = !WCfg.lightText(cbg, cop, WCfg.txMode(c, id));
      WCfg.paint(rv, cbg, cop);
      applyTheme(rv, cl);
      m.updateAppWidget(id, rv);
    }
  }

  static String tail(JSONArray r, int idx) {
    try {
      int v = r.getInt(idx);
      if ("td".equals("td")) return v + "\uc138\ud2b8";
      if (v <= 0) return "\uc624\ub298";
      return v + "\uc77c \uc804";
    } catch (Exception e) { return ""; }
  }

  static void applyTheme(RemoteViews rv, boolean lt) {
    rv.setTextColor(R.id.root_hd, WTheme.head(lt));
    rv.setTextColor(R.id.root_cnt, WTheme.mute(lt));
    rv.setTextColor(R.id.root_empty, WTheme.dim(lt));
    WTheme.tint(rv, N, WTheme.label(lt));
    WTheme.tint(rv, V, WTheme.value(lt));
    WTheme.tint(rv, S, WTheme.dim(lt));
  }
}
