package com.lwd20.traininglog;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.widget.RemoteViews;

public class TimerService extends Service {
  public static final String ACT_START = "start";
  public static final String ACT_STOP = "stop";
  private static final String CH = "rest";
  private final Handler h = new Handler(Looper.getMainLooper());
  private long ivMs = 120000L;
  private final Runnable pulse = new Runnable() {
    @Override public void run() {
      try {
        Vibrator vb = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        long[] w = {0, 240, 130, 240};
        if (vb != null) {
          if (Build.VERSION.SDK_INT >= 26) vb.vibrate(VibrationEffect.createWaveform(w, -1));
          else vb.vibrate(w, -1);
        }
      } catch (Exception e) {}
      bringApp();
      h.postDelayed(this, ivMs);
    }
  };

  private void bringApp() {
    Intent i = new Intent(this, MainActivity.class);
    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    try { startActivity(i); } catch (Exception e) {}
    /* 백그라운드 실행 제한 대비: 풀스크린 인텐트 헤드업 */
    try {
      NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
      if (Build.VERSION.SDK_INT >= 26) {
        NotificationChannel c = new NotificationChannel("alert", "Rest alert", NotificationManager.IMPORTANCE_HIGH);
        c.setShowBadge(false);
        nm.createNotificationChannel(c);
      }
      Notification.Builder nb;
      if (Build.VERSION.SDK_INT >= 26) nb = new Notification.Builder(this, "alert");
      else nb = new Notification.Builder(this);
      PendingIntent fpi = PendingIntent.getActivity(this, 2, i,
          PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      nb.setSmallIcon(R.drawable.ic_stat_timer)
        .setColor(0xFFCFA648)
        .setContentTitle("Rest done — next set")
        .setAutoCancel(true)
        .setContentIntent(fpi)
        .setFullScreenIntent(fpi, true);
      nm.notify(2, nb.build());
      h.postDelayed(new Runnable() { public void run() { nm.cancel(2); } }, 8000L);
    } catch (Exception e) {}
  }

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    String act = intent == null ? ACT_STOP : intent.getAction();
    if (ACT_START.equals(act)) {
      long elapsed = intent.getLongExtra("elapsed", 0L);
      ivMs = intent.getLongExtra("iv", 120000L);
      if (ivMs < 30000L) ivMs = 30000L;
      startForeground(1, build(elapsed));
      h.removeCallbacksAndMessages(null);
      long delay = ivMs - (elapsed % ivMs);
      if (delay < 500L) delay += ivMs;
      h.postDelayed(pulse, delay);
    } else {
      h.removeCallbacksAndMessages(null);
      if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
      else stopForeground(true);
      stopSelf();
    }
    return START_NOT_STICKY;
  }

  @Override public void onDestroy() {
    h.removeCallbacksAndMessages(null);
    super.onDestroy();
  }

  private Notification build(long elapsedMs) {
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(CH, "Rest timer", NotificationManager.IMPORTANCE_LOW);
      c.setShowBadge(false);
      nm.createNotificationChannel(c);
    }
    Notification.Builder nb;
    if (Build.VERSION.SDK_INT >= 26) nb = new Notification.Builder(this, CH);
    else nb = new Notification.Builder(this);
    Intent i = new Intent(this, MainActivity.class);
    PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE);
    RemoteViews rv = new RemoteViews(getPackageName(), R.layout.noti_rest);
    rv.setChronometer(R.id.ch, SystemClock.elapsedRealtime() - elapsedMs, null, true);
    nb.setSmallIcon(R.drawable.ic_stat_timer)
      .setColor(0xFF1A140C)
      .setColorized(true)
      .setWhen(System.currentTimeMillis() - elapsedMs)
      .setOngoing(true)
      .setStyle(new Notification.DecoratedCustomViewStyle())
      .setCustomContentView(rv)
      .setContentIntent(pi);
    return nb.build();
  }
}
