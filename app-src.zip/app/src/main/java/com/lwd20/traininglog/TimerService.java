package com.lwd20.traininglog;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.widget.RemoteViews;

public class TimerService extends Service {
  public static final String ACT_START = "start";
  public static final String ACT_STOP = "stop";
  private static final String CH = "rest";

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    String act = intent == null ? ACT_STOP : intent.getAction();
    if (ACT_START.equals(act)) {
      long elapsed = intent.getLongExtra("elapsed", 0L);
      startForeground(1, build(elapsed));
    } else {
      if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
      else stopForeground(true);
      stopSelf();
    }
    return START_NOT_STICKY;
  }

  private Notification build(long elapsedMs) {
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(CH, "Rest timer", NotificationManager.IMPORTANCE_LOW);
      c.setShowBadge(false);
      nm.createNotificationChannel(c);
    }
    Notification.Builder nb;
    if (Build.VERSION.SDK_INT >= 26) nb = new Notification.Builder(this, CH);
    else nb = new Notification.Builder(this);
    Intent i = new Intent(this, MainActivity.class);
    PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE);
    RemoteViews rv = new RemoteViews(getPackageName(), R.layout.noti_rest);
    rv.setChronometer(R.id.ch, SystemClock.elapsedRealtime() - elapsedMs, null, true);
    nb.setSmallIcon(R.drawable.ic_stat_timer)
      .setColor(0xFF1A140C)
      .setColorized(true)
      .setWhen(System.currentTimeMillis() - elapsedMs)
      .setOngoing(true)
      .setStyle(new Notification.DecoratedCustomViewStyle())
      .setCustomContentView(rv)
      .setContentIntent(pi);
    return nb.build();
  }
}
