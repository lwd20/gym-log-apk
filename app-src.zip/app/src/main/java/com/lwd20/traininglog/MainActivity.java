package com.lwd20.traininglog;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Environment;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.concurrent.CountDownLatch;
import android.widget.RemoteViews;
import android.os.SystemClock;

public class MainActivity extends Activity {
  private static final String URL = "https://lwd20.github.io/Health_Logging/";
  private static final String CH = "rest";
  private WebView web;
  private ValueCallback<android.net.Uri[]> fileCb;
  private static final int PICK_FILE = 11;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    if (Build.VERSION.SDK_INT >= 33
        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
    }
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(CH, "Rest timer", NotificationManager.IMPORTANCE_LOW);
      c.setShowBadge(false);
      nm.createNotificationChannel(c);
    }
    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        String u = r.getUrl().toString();
        if (u.startsWith(URL)) return false;
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<android.net.Uri[]> cb, FileChooserParams p) {
        if (fileCb != null) fileCb.onReceiveValue(null);
        fileCb = cb;
        Intent it = null;
        try { it = p.createIntent(); } catch (Exception e) {}
        if (it == null) {
          it = new Intent(Intent.ACTION_GET_CONTENT);
          it.addCategory(Intent.CATEGORY_OPENABLE);
          it.setType("*/*");
        }
        try {
          startActivityForResult(Intent.createChooser(it, "Select backup"), PICK_FILE);
        } catch (Exception e) {
          fileCb = null;
          return false;
        }
        return true;
      }
    });
    web.addJavascriptInterface(new Bridge(), "AndroidTimer");
    web.addJavascriptInterface(new Bridge(), "AndroidApp");
    web.addJavascriptInterface(new ClipBridge(), "AndroidClip");
    web.addJavascriptInterface(new FileBridge(), "AndroidFile");
    web.addJavascriptInterface(new WidgetBridge(), "AndroidWidget");
    setContentView(web);
    web.loadUrl(URL);
  }

  class Bridge {
    @JavascriptInterface public void start(double elapsedMs) { start(elapsedMs, 120000d); }
    @JavascriptInterface public void start(double elapsedMs, double ivMs) {
      Intent i = new Intent(MainActivity.this, TimerService.class);
      i.setAction(TimerService.ACT_START);
      i.putExtra("elapsed", (long) elapsedMs);
      i.putExtra("iv", (long) ivMs);
      if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
      else startService(i);
    }
    @JavascriptInterface public void exit() {
      runOnUiThread(new Runnable() { @Override public void run() {
        try { finishAffinity(); } catch (Exception e) { finish(); }
      }});
    }
    @JavascriptInterface public String pull() {
      try {
        android.content.SharedPreferences sp = getSharedPreferences("timer", 0);
        String a = sp.getString("act", "");
        if (a == null || a.length() == 0) return "";
        sp.edit().remove("act").apply();
        return a;
      } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public void stop() {
      Intent i = new Intent(MainActivity.this, TimerService.class);
      i.setAction(TimerService.ACT_STOP);
      try { startService(i); } catch (Exception e) {}
      try { stopService(new Intent(MainActivity.this, TimerService.class)); } catch (Exception e) {}
    }
  }

  class WidgetBridge {
    @JavascriptInterface public void sync(String json) {
      try {
        getSharedPreferences("widget", 0).edit().putString("data", json).apply();
        VolumeWidget.push(MainActivity.this);
        WeekWidget.push(MainActivity.this);
        FreqWidget.push(MainActivity.this);
      } catch (Exception e) {}
    }
  }

  class ClipBridge {
    @JavascriptInterface public String read() {
      final String[] out = new String[]{""};
      final CountDownLatch latch = new CountDownLatch(1);
      runOnUiThread(new Runnable() { public void run() {
        try {
          ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
          ClipData cd = cm.getPrimaryClip();
          if (cd != null && cd.getItemCount() > 0) {
            CharSequence t = cd.getItemAt(0).coerceToText(MainActivity.this);
            if (t != null) out[0] = t.toString();
          }
        } catch (Exception e) {}
        latch.countDown();
      }});
      try { latch.await(); } catch (InterruptedException e) {}
      return out[0];
    }
  }

  class FileBridge {
    @JavascriptInterface public boolean save(String name, String content) {
      try {
        if (Build.VERSION.SDK_INT >= 29) {
          ContentValues cv = new ContentValues();
          cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
          cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
          android.net.Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
          if (uri == null) return false;
          OutputStream os = getContentResolver().openOutputStream(uri);
          os.write(content.getBytes("UTF-8"));
          os.close();
        } else {
          File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
          if (!dir.exists()) dir.mkdirs();
          FileOutputStream fo = new FileOutputStream(new File(dir, name));
          fo.write(content.getBytes("UTF-8"));
          fo.close();
        }
        runOnUiThread(new Runnable() { public void run() {
          Toast.makeText(MainActivity.this, "Downloads에 저장됨", Toast.LENGTH_SHORT).show();
        }});
        return true;
      } catch (Exception e) { return false; }
    }
  }

  @Override protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req, res, data);
    if (req == PICK_FILE && fileCb != null) {
      android.net.Uri[] out = null;
      if (res == RESULT_OK) {
        out = WebChromeClient.FileChooserParams.parseResult(res, data);
        if (out == null && data != null && data.getData() != null) out = new android.net.Uri[]{ data.getData() };
      }
      fileCb.onReceiveValue(out);
      fileCb = null;
    }
  }

  @Override public void onBackPressed() {
    /* 웹이 pushState로 히스토리를 쌓으므로 항상 웹에 위임 — 시트 닫기/종료 확인은 웹이 판단 */
    if (web.canGoBack()) { web.goBack(); return; }
    try { web.evaluateJavascript("(function(){try{exitAsk(true);return 1;}catch(e){return 0;}})()", null); }
    catch (Exception e) { super.onBackPressed(); }
  }
}
