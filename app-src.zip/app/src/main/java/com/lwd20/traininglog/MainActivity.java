package com.lwd20.traininglog;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private static final String URL = "https://lwd20.github.io/Health_Logging/";
  private static final String CH = "rest";
  private WebView web;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    if (Build.VERSION.SDK_INT >= 33
        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
    }
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(CH, "Rest timer", NotificationManager.IMPORTANCE_LOW);
      c.setShowBadge(false);
      nm.createNotificationChannel(c);
    }
    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        String u = r.getUrl().toString();
        if (u.startsWith(URL)) return false;
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        return true;
      }
    });
    web.addJavascriptInterface(new Bridge(), "AndroidTimer");
    setContentView(web);
    web.loadUrl(URL);
  }

  class Bridge {
    @JavascriptInterface public void start(double elapsedMs) {
      Notification.Builder nb;
      if (Build.VERSION.SDK_INT >= 26) nb = new Notification.Builder(MainActivity.this, CH);
      else nb = new Notification.Builder(MainActivity.this);
      Intent i = new Intent(MainActivity.this, MainActivity.class);
      PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 0, i, PendingIntent.FLAG_IMMUTABLE);
      nb.setSmallIcon(R.drawable.ic_stat_timer)
        .setContentTitle("Rest")
        .setContentText("Training Log")
        .setUsesChronometer(true)
        .setWhen(System.currentTimeMillis() - (long) elapsedMs)
        .setOngoing(true)
        .setContentIntent(pi);
      NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
      nm.notify(1, nb.build());
    }
    @JavascriptInterface public void stop() {
      NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
      nm.cancel(1);
    }
  }

  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }
}
